import React from 'react';
import ReactDOM from 'react-dom';

import ButtonComponent from './mybutton.component';

export default class ButtonListComponent extends React.Component{
    
    constructor(){
        super();
        this.state = {buttonlist:[50,70,90]};
    }
    shouldComponentUpdate(){
        console.log(arguments);
        return true;
    }
    
addButtonHandler(){
     var txt =   ReactDOM.findDOMNode(this.refs.inputValue);
     var theValue = txt.value;
     var newList = [...this.state.buttonlist,theValue];// es 6 spread operator
     this.setState({buttonlist:newList}); 
}

    render(){
  var buttonsTobeCreated = this.state.buttonlist.map((item,index) =>{
            return <ButtonComponent count={item} key={index * Math.random()} />            
        });
       return <div >   
            <input type="text" ref="inputValue" /> 
            <input type="button"  value="Add>>"
             className="btn btn-primary"
             onClick={this.addButtonHandler.bind(this)}
              />         
                 {buttonsTobeCreated}
                </div>
                }
}