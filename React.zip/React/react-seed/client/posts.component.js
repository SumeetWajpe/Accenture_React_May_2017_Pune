import React from 'react';
export default class PostsComponent extends React.Component{
    constructor(props){
      super(props);
      this.state = {};
  }

//   componentDidMount(){
//       var self = this;
//     $.get("https://jsonplaceholder.typicode.com/photos/1",
//     function(response){
//                 self.setState(response);
//     });// eof get
//   } // eof componentDidMount

// OR using ES 6
  componentDidMount(){ 
    $.get("https://jsonplaceholder.typicode.com/posts",
    (response)=> {
                //console.log(response);
                //this.setState(response);
                window.sessionStorage.setItem("postsdata",response)
    });// eof get
  } // eof componentDidMount

    render(){
       return <div >
                  </div>
                }
}