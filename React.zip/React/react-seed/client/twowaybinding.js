import React from 'react';

export default class BindingComponent extends React.Component{
    constructor(){        super();     
    }
    componentWillMount(){
        // set state, initialize
         this.state = {coursename:'React'}; console.log('Within componentWillMount !');
    }
    componentDidMount(){ // called after render         // make ajaxfied request
        console.log('Within componentDidMount !');
    }
     shouldComponentUpdate(){        // performance        
        console.log('Within shouldComponentUpdate !');
        if(this.state.coursename.length > 10){
            return false;
        }
        else{
        return true;
        }
    }
    componentWillUpdate(){    
        console.log('Within componentWillUpdate !');       
    }
    componentDidUpdate(){    
        console.log('Within componentDidUpdate !');       
    }

      


    handlerForOnChange(e){
            this.setState({coursename:e.target.value});
    }

    render(){
        console.log('Within render !');
        
       return <div>                   
                  Coursename :   <input type="text" 
                  value={this.state.coursename} 
                  onChange={this.handlerForOnChange.bind(this)} />
                   {this.state.coursename}
                </div>
                }
}