// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
//import HelloComponent from './hello.component';
//import BlogComponent from './blog.component';
//import ShoppingCartComponent from './shoppingcart.component';
 //import ButtonListComponent from './buttonlist.component';

import PostsComponent from './posts.component';

//import BindingComponent from './twowaybinding';


ReactDOM.render(
    <PostsComponent />
    ,
    document.getElementById('content')
    );