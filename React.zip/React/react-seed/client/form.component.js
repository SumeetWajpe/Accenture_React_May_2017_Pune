import React from 'react';
export default class FormsComponent extends React.Component{
    render(){
       return <div>                   
                    <h2> Enter your comments here </h2>
                    <input type="text" />    
                    <input type="button" value="Add" />
                </div>
                }
}