import React from 'react';
import FormsComponent from './form.component';
import CommentsComponent from './comments.component';


export default class BlogComponent extends React.Component{
    render(){
       return <div>                   
                          <CommentsComponent />   
                          <FormsComponent /> 
                          <FormsComponent />                             
                          <FormsComponent />                             
                          <FormsComponent />                             
                                                      
                </div>
                }
}