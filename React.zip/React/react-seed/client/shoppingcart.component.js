import React from 'react';
import Product from './product.component';
export default class ShoppingCartComponent extends React.Component{
    
    

    render(){
       return <div>                   
                    <h2> Shopping Cart </h2>
                     <Product pname="Lenovo Laptop" />
                     <Product pname="Lenovo Mobile"  />
                     <Product pname="Lenovo Palmtop"  />
                     
                </div>
                }
}