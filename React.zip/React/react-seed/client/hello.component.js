import React from 'react';
export default class HelloComponent extends React.Component{
    render(){
       // return {/*<h1 className="Header">  Hello ReactJS using ES 6 ! </h1>*/}
       return <div>
                    <h1> Heading H1 </h1>
                    <h2> Heading in h2 </h2>
                    <p>  Paragraph ! </p>    
                </div>
                }
}