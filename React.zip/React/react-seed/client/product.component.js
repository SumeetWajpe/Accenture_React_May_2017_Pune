import React from 'react';

export default class ProductComponent extends React.Component{
    render(){
       return <div className="Product">                   
                    <h1> {this.props.pname} </h1>
                     <b> Price : 40000 </b><br/>
                     <b> Quantity : 40 </b><br/>
                     <b> Description : Good quality,sturdy ! </b>                    
                     
                </div>
                }
}