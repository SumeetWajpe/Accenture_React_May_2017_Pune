import React from 'react';
export default class ButtonComponent extends React.Component{
    constructor(props){
      super(props);
      this.state = {counter: +this.props.count};//+ converts string to number
  }  
  incrementCount(){
       this.setState({counter: this.state.counter + 1});
   }
    render(){
       return <div >       
                     <button type="button"  className="btn btn-success"
    onClick={this.incrementCount.bind(this)}>
    {this.state.counter}</button>
                </div>
                }
}