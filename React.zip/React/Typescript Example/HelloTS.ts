let x:number = 10;
x = 20;