// test cases (Jasmine)

function Addition(x,y){
    return x + y;
}

describe("A suite", function() {
  it("contains spec with an expectation", function() {
    expect(true).toBe(true);
  });
});

describe("Addition Test", function() {
  it("adds two numbers", function() {
    expect(Addition(20,30)).toBe(50);
  });
});
