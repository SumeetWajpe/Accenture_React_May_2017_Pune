import React from 'react';
import PhotoDetails from './PhotoDetails'

export default class Album extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return <div>
             <h1>  Albums </h1>
                {
                        this.props.myposts.map((item,index) => {
                            return <PhotoDetails post={item} i={index} {...this.props} />
                        })
                }
             </div>
    }
}