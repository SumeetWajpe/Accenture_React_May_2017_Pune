import * as actions from '../actions/actionCreators';
import {connect} from 'react-redux';
import Main from './Main';
import {bindActionCreators} from 'redux';

function mapStatetoToProps(stateMeansStore){
    return {
            myposts:stateMeansStore.posts,
            mycomments:stateMeansStore.comments
    }
}
function mapDispatchToProps(dispatch){
    return bindActionCreators(actions,dispatch);
}
var App = connect(mapStatetoToProps,mapDispatchToProps)(Main);
export default App;