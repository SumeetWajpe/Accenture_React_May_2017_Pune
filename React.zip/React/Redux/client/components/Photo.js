import React from 'react';

export default class Photo extends React.Component{
    render(){
        return <h1> This is Photo Component ! </h1>
    }
}