import React from 'react';

export default class PhotoDetails extends React.Component{
    constructor(props){
        super(props);
    }
    render(){
        return <div>
                        <b>{this.props.post.caption}</b>
                         <button className="btn btn-sm btn-success"
                         onClick={this.props.IncreementLikes.bind(this,this.props.i)}
                         >
                             {this.props.post.likes}
                        </button>
                    </div>
    }
}