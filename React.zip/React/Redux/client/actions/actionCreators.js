export function IncreementLikes(index){
    return {type:'INCREMENT_LIKES',index:index};
}

export function AddPosts(){
    return {type:'ADD_POST'}
} 

export function RemovePosts(){
    return {type:'REMOVE_POST'}
} 