import {createStore} from 'redux';

// data 
import posts from './data/posts';
import comments from './data/comments';

import rootReducer from './reducers/rootReducer';

//var defaultState = {posts:posts,comments:comments};
var defaultState = {posts,comments}; // using ES 6


var store = createStore(rootReducer,defaultState);

export default store;