export default function posts(defState=[],action){
// change the store !
switch(action.type){
case 'INCREMENT_LIKES':
        console.log('Within posts Reducer !');
        var index = action.index;
        return [
            ...defState.slice(0,index),
            {...defState[index],likes:defState[index].likes + 1},
            ...defState.slice(index + 1)
        ];
        
    default:
        return defState;

}
}