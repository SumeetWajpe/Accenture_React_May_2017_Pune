export default function comments(defState=[],action){
// change the store !

switch(action.type){

case 'ADD_COMMENTS':
        console.log('Within comments Reducer !');
        return defState; // change store here !
    default:
        return defState;

}

}