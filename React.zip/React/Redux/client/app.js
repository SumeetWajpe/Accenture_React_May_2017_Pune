// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import {Provider} from 'react-redux';

import Main from './components/Main';
import App from './components/MainScript';

import Photo from './components/Photo';
import Album from './components/Album';

import store from './store';
{/*Provides makes store available*/}
var router = <Provider store={store}> 
                    <Router history={browserHistory}>
                        <Route path="/" component={App}>
                            <IndexRoute component={Album} ></IndexRoute>
                            <Route path="/photo" component={Photo} ></Route>
                        </Route>
                    </Router>
                    </Provider>
ReactDOM.render(router,document.getElementById('content'))
