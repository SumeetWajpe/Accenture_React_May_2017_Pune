/// <reference path="../typings/modules/react/index.d.ts" />
/// <reference path="../typings/modules/react-dom/index.d.ts" />
"use strict";
var React = require("react");
var ReactDOM = require("react-dom");
//import Main from "./components/Main";
var ShoppingCart_1 = require('./components/ShoppingCart');
ReactDOM.render(<ShoppingCart_1.default></ShoppingCart_1.default>, document.getElementById("content"));
