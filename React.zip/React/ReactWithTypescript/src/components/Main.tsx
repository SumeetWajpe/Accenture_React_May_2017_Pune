﻿/// <reference path="../../typings/modules/react/index.d.ts" />


import * as React from "react";

export default class Main extends React.Component<any, any> {
        render() {
        return (            
            <div>
                Hello !               
            </div>
        );
    }

    
}